/**
 * 
 */
/**
 * @author ��ȿ��
 *
 */
module com.checkMemory {
	exports com.checkMemory;
}